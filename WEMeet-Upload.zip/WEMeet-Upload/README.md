# WeMeet

A lightweight WPF desktop email client with IMAP/SMTP support, local caching, and Material Design UI.

## Features

- **Multi-account** — Add, manage, and switch between multiple email accounts
- **Receive emails** — IMAP protocol with folder browsing, header sync, and full body fetch
- **Send emails** — SMTP compose, reply, reply-all, and forward with quoted original text
- **Forward** — Forward messages with original headers preserved
- **Offline support** — SQLite local cache; messages available when disconnected
- **Auto-discovery** — Server settings auto-detected for 25+ providers (Gmail, Outlook, QQ, 163, Yahoo, iCloud, etc.)
- **HTML rendering** — WebBrowser control renders formatted emails correctly; plain text shown with monospace font
- **Auto-refresh** — Periodic inbox sync every 5 minutes
- **Read/unread** — Unread dot indicator, badge count, and sync read state back to server
- **Delete messages** — Delete on both IMAP server and local DB
- **Sent folder sync** — Appends sent messages to IMAP Sent folder (supports Chinese folder names)
- **Password security** — DPAPI encryption scoped to current user
- **Keyboard shortcuts** — Ctrl+N (Compose), R (Reply), F5 (Refresh), Del (Delete)
- **Smart SSL** — Auto-detects SSL mode (implicit SSL on port 465/993, STARTTLS on port 587) for maximum compatibility
- **Provider guidance** — Shows provider-specific tips (App Passwords, Authorization Codes) when adding accounts

## Supported Providers

Gmail, Googlemail, Outlook, Hotmail, Live, Yahoo, QQ, Foxmail, 163, 126, Yeah, Sina, Aliyun, iCloud, Me.com, Zoho, ProtonMail (via Bridge), Yandex, Mail.ru, GMX, WEB.DE, T-Online, and custom domains via manual configuration.

## Tech Stack

- **.NET 8** (Windows) + **WPF**
- **MailKit** — IMAP/SMTP protocol implementation
- **Entity Framework Core** — SQLite local storage
- **CommunityToolkit.Mvvm** — MVVM source generators
- **Material Design in XAML** — UI theme and components
- **HtmlAgilityPack** — HTML sanitization (script/event handler removal)

## Project Structure

```
WEMeet/
├── Converters/          # NullToVisibilityConverter, DateConverter, InverseBoolConverter
├── Models/              # MailAccount, MailFolder, MailMessage (EF Core entities)
├── Services/
│   ├── AccountService   # CRUD + DPAPI password encryption
│   ├── AutoDiscovery    # Provider server settings lookup
│   ├── ImapService      # IMAP connect, fetch, mark, delete, append
│   ├── SmtpService      # SMTP connect, send, message builder
│   └── StorageService   # WeMeetDbContext (EF Core SQLite schema)
├── ViewModels/
│   ├── MainViewModel    # Account/folder/message orchestration
│   ├── AddAccountVM     # Add-account dialog logic
│   └── ComposeVM        # Compose/reply/send logic
├── Views/
│   ├── MainWindow       # 3-pane UI (folders, message list, content)
│   ├── AddAccountDialog # Add-account form
│   └── ComposeWindow    # Compose/reply form
└── App.xaml             # Material Design theme bootstrap
```

## Getting Started

1. **Prerequisites**: .NET 8 SDK (Windows)
2. **Build & Run**:
   ```bash
   dotnet build
   dotnet run
   ```
   Or use `build.cmd` for a one-click build.
3. **Add an account**: Click the account-plus icon, enter your email and password. The app will show provider-specific instructions.

## Notes

- **Gmail/Outlook/Yahoo**: You must generate an **App Password** in your account security settings. Regular passwords won't work if 2FA is enabled.
- **QQ/Foxmail/163/126/Yeah**: You need an **Authorization Code** (授权码), NOT your login password. Enable IMAP/SMTP in your mail settings first, then generate an authorization code.
- **ProtonMail**: Requires [Proton Mail Bridge](https://proton.me/mail/bridge) running locally.
- **iCloud**: Requires an App-Specific Password from appleid.apple.com.
- Port 465 uses implicit SSL, port 587 uses STARTTLS — both are auto-detected.