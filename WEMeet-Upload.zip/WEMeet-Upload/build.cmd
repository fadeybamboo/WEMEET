@echo off
title WeMeet - Build
echo ============================================
echo   WeMeet Email Client - Build Script
echo ============================================
echo.

:: Check .NET 8 SDK
where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] .NET SDK not found. Please install .NET 8 SDK:
    echo         https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

dotnet --version | findstr /r "^8\." >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] .NET 8 SDK required. Current version:
    dotnet --version
    echo         Download: https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

echo [OK] .NET 8 SDK detected
echo.

:: Restore packages
echo [1/3] Restoring NuGet packages...
dotnet restore
if %errorlevel% neq 0 (
    echo [ERROR] Package restore failed.
    pause
    exit /b 1
)

:: Build Release
echo.
echo [2/3] Building Release...
dotnet build -c Release
if %errorlevel% neq 0 (
    echo [ERROR] Build failed.
    pause
    exit /b 1
)

:: Show result
echo.
echo [3/3] Build complete!
echo ============================================
echo   Output: WEMeet\bin\Release\net8.0-windows\
echo   Executable: WeMeet.exe
echo ============================================
echo.

:: Ask to run
set /p RUN="Run WeMeet now? (Y/N): "
if /i "%RUN%"=="Y" (
    echo Starting WeMeet...
    start "" "WEMeet\bin\Release\net8.0-windows\WeMeet.exe"
)

pause