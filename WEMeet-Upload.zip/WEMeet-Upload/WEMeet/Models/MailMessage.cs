using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WEMeet.Models;

public class MailMessage
{
    [Key]
    public int Id { get; set; }

    public int AccountId { get; set; }

    public uint Uid { get; set; }

    public string FolderName { get; set; } = "INBOX";

    public string From { get; set; } = string.Empty;

    public string FromAddress { get; set; } = string.Empty;

    public string To { get; set; } = string.Empty;

    public string Cc { get; set; } = string.Empty;

    public string Subject { get; set; } = string.Empty;

    public string Body { get; set; } = string.Empty;

    public string? HtmlBody { get; set; }

    public DateTime Date { get; set; }

    public bool IsRead { get; set; }

    public bool HasAttachments { get; set; }

    public string? MessageId { get; set; }

    public string? InReplyTo { get; set; }

    public bool IsDeleted { get; set; }

    [ForeignKey(nameof(AccountId))]
    public MailAccount? Account { get; set; }
}
