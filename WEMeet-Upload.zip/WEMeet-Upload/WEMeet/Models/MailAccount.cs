using System.ComponentModel.DataAnnotations;

namespace WEMeet.Models;

public class MailAccount
{
    [Key]
    public int Id { get; set; }

    [Required]
    public string Name { get; set; } = string.Empty;

    [Required]
    public string Email { get; set; } = string.Empty;

    [Required]
    public string ImapHost { get; set; } = string.Empty;

    public int ImapPort { get; set; } = 993;
    public bool ImapSsl { get; set; } = true;

    [Required]
    public string SmtpHost { get; set; } = string.Empty;

    public int SmtpPort { get; set; } = 587;
    public bool SmtpSsl { get; set; } = true;

    public string EncryptedPassword { get; set; } = string.Empty;

    public DateTime? LastSyncDate { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    // Navigation properties
    public List<MailMessage> Messages { get; set; } = new();
    public List<MailFolder> Folders { get; set; } = new();
}
