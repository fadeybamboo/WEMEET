using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WEMeet.Models;

public class MailFolder
{
    [Key]
    public int Id { get; set; }

    public int AccountId { get; set; }

    public string Name { get; set; } = string.Empty;

    public string FullName { get; set; } = string.Empty;

    public int UnreadCount { get; set; }

    public int TotalCount { get; set; }

    [ForeignKey(nameof(AccountId))]
    public MailAccount? Account { get; set; }
}
