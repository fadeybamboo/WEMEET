﻿using System.Windows;

namespace WEMeet;

public partial class App : Application
{
}
