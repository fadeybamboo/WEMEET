using System.Windows;
using WEMeet.Models;
using WEMeet.ViewModels;

namespace WEMeet.Views;

public partial class ComposeWindow : Window
{
    private readonly ComposeViewModel _vm;

    public ComposeWindow(MailAccount account)
    {
        InitializeComponent();
        _vm = new ComposeViewModel(account);
        DataContext = _vm;
        Title = _vm.WindowTitle;
        BindFields();
    }

    public ComposeWindow(MailAccount account, MailMessage originalMessage, bool replyAll = false, bool forward = false)
    {
        InitializeComponent();
        _vm = new ComposeViewModel(account, originalMessage, replyAll, forward);
        DataContext = _vm;
        Title = _vm.WindowTitle;
        BindFields();
    }

    private void BindFields()
    {
        ToBox.Text = _vm.To;
        CcBox.Text = _vm.Cc;
        SubjectBox.Text = _vm.Subject;
        BodyBox.Text = _vm.Body;

        _vm.PropertyChanged += (s, e) =>
        {
            switch (e.PropertyName)
            {
                case nameof(ComposeViewModel.StatusMessage):
                    StatusText.Text = _vm.StatusMessage;
                    break;
                case nameof(ComposeViewModel.IsSending):
                    SendProgress.Visibility = _vm.IsSending ? Visibility.Visible : Visibility.Collapsed;
                    break;
            }
        };
    }

    private async void Send_Click(object sender, RoutedEventArgs e)
    {
        // Update VM from UI
        _vm.To = ToBox.Text;
        _vm.Cc = CcBox.Text;
        _vm.Subject = SubjectBox.Text;
        _vm.Body = BodyBox.Text;

        await _vm.SendCommand.ExecuteAsync(null);

        if (_vm.SentSuccessfully)
        {
            Close();
        }
    }
}
