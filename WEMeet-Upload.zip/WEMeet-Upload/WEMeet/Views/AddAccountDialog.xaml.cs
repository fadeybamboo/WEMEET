using System.ComponentModel;
using System.Windows;
using WEMeet.ViewModels;

namespace WEMeet.Views;

public partial class AddAccountDialog : Window
{
    public AddAccountDialog()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        if (DataContext is AddAccountViewModel vm)
            vm.PropertyChanged += OnVmPropertyChanged;
    }

    private void OnVmPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(AddAccountViewModel.AccountAdded)
            && DataContext is AddAccountViewModel { AccountAdded: true })
            Dispatcher.Invoke(() => { DialogResult = true; Close(); });
    }

    private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (DataContext is AddAccountViewModel vm)
            vm.Password = PasswordBox.Password;
    }
}
