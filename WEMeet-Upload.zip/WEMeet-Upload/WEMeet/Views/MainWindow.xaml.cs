using System.ComponentModel;
using System.Windows;
using WEMeet.ViewModels;

namespace WEMeet.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (DataContext is MainViewModel vm)
        {
            FolderTree.ItemsSource = vm.Accounts;
            vm.Accounts.CollectionChanged += (s, args) =>
            {
                FolderTree.ItemsSource = null;
                FolderTree.ItemsSource = vm.Accounts;
            };
            vm.PropertyChanged += OnViewModelPropertyChanged;
        }
    }

    private void OnViewModelPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(MainViewModel.MessageBody) or nameof(MainViewModel.HasHtmlBody))
            Dispatcher.Invoke(UpdateEmailBrowser);
    }

    private void UpdateEmailBrowser()
    {
        if (DataContext is not MainViewModel vm) return;
        var html = vm.HasHtmlBody
            ? vm.MessageHtmlBody
            : $"<pre style='font:13px Consolas;margin:0'>{System.Net.WebUtility.HtmlEncode(vm.MessageBody)}</pre>";
        EmailBrowser.NavigateToString(html);
    }

    private void FolderTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (DataContext is MainViewModel vm)
        {
            if (e.NewValue is FolderNode folder)
                vm.SelectedFolder = folder;
            else if (e.NewValue is AccountNode account)
                vm.SelectedAccount = account;
        }
    }
}
