using System.IO;
using Microsoft.EntityFrameworkCore;
using WEMeet.Models;

namespace WEMeet.Services;

public class WeMeetDbContext : DbContext
{
    public DbSet<MailAccount> Accounts { get; set; } = null!;
    public DbSet<MailMessage> Messages { get; set; } = null!;
    public DbSet<MailFolder> Folders { get; set; } = null!;

    private readonly string _dbPath;

    public WeMeetDbContext()
    {
        var appData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "WEMeet");
        Directory.CreateDirectory(appData);
        _dbPath = Path.Combine(appData, "wemeet.db");
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite($"Data Source={_dbPath}");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MailAccount>(entity =>
        {
            entity.HasIndex(e => e.Email).IsUnique();
            entity.HasMany(e => e.Messages)
                  .WithOne(m => m.Account)
                  .HasForeignKey(m => m.AccountId)
                  .OnDelete(DeleteBehavior.Cascade);
            entity.HasMany(e => e.Folders)
                  .WithOne(f => f.Account)
                  .HasForeignKey(f => f.AccountId)
                  .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<MailMessage>(entity =>
        {
            entity.HasIndex(e => new { e.AccountId, e.Uid, e.FolderName }).IsUnique();
            entity.HasIndex(e => e.Date);
            entity.HasIndex(e => e.IsRead);
        });

        modelBuilder.Entity<MailFolder>(entity =>
        {
            entity.HasIndex(e => new { e.AccountId, e.FullName }).IsUnique();
        });
    }

    public void EnsureCreated()
    {
        Database.EnsureCreated();
    }
}
