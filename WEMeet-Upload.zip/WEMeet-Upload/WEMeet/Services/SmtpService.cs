using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace WEMeet.Services;

public class SmtpService
{
    private static SecureSocketOptions GetSslOptions(int port, bool useSsl)
    {
        if (!useSsl) return SecureSocketOptions.None;
        return port switch
        {
            465 => SecureSocketOptions.SslOnConnect,       // Implicit SSL
            587 => SecureSocketOptions.StartTlsWhenAvailable, // STARTTLS
            25 => SecureSocketOptions.StartTlsWhenAvailable,  // STARTTLS (if available)
            _ => SecureSocketOptions.StartTlsWhenAvailable
        };
    }

    private static string FormatAuthError(Exception ex, string host)
    {
        var msg = ex.Message;
        if (msg.Contains("Authentication failed", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("Invalid credentials", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("Login failed", StringComparison.OrdinalIgnoreCase))
        {
            return $"SMTP Authentication failed. For Gmail/Outlook/Yahoo: use an App Password. " +
                   $"For QQ/163/126: use an Authorization Code. Detail: {msg}";
        }
        if (msg.Contains("connect", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("timeout", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("refused", StringComparison.OrdinalIgnoreCase))
        {
            return $"Cannot connect to {host}. Check server address and port. Detail: {msg}";
        }
        return msg;
    }

    public async Task<(bool Success, string Error)> TestConnectionAsync(
        string host, int port, bool ssl, string email, string password)
    {
        try
        {
            using var client = new SmtpClient();
            await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
            await client.AuthenticateAsync(email, password);
            await client.DisconnectAsync(true);
            return (true, string.Empty);
        }
        catch (Exception ex)
        {
            return (false, FormatAuthError(ex, host));
        }
    }

    public async Task<(bool Success, string Error)> SendEmailAsync(
        string host, int port, bool ssl, string email, string password,
        MimeMessage message)
    {
        try
        {
            using var client = new SmtpClient();
            await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
            await client.AuthenticateAsync(email, password);
            await client.SendAsync(message);
            await client.DisconnectAsync(true);
            return (true, string.Empty);
        }
        catch (Exception ex)
        {
            return (false, FormatAuthError(ex, host));
        }
    }

    public static MimeMessage CreateNewMessage(
        string fromEmail, string fromName,
        string to, string? cc, string subject, string body, bool isHtml)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(fromName, fromEmail));

        foreach (var addr in ParseAddresses(to))
            message.To.Add(addr);

        if (!string.IsNullOrWhiteSpace(cc))
        {
            foreach (var addr in ParseAddresses(cc))
                message.Cc.Add(addr);
        }

        message.Subject = subject;

        if (isHtml)
        {
            var builder = new BodyBuilder { HtmlBody = body };
            message.Body = builder.ToMessageBody();
        }
        else
        {
            message.Body = new TextPart("plain") { Text = body };
        }

        return message;
    }

    public static MimeMessage CreateReplyMessage(
        string fromEmail, string fromName,
        string toAddress, string toName,
        string? cc, string subject, string body, bool isHtml,
        string? originalMessageId, string? quotedBody)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(fromName, fromEmail));
        message.To.Add(new MailboxAddress(toName, toAddress));

        if (!string.IsNullOrWhiteSpace(cc))
        {
            foreach (var addr in ParseAddresses(cc))
                message.Cc.Add(addr);
        }

        message.Subject = subject;
        message.InReplyTo = originalMessageId;
        if (!string.IsNullOrEmpty(originalMessageId))
            message.References.Add(originalMessageId);

        string fullBody = body;
        if (!string.IsNullOrEmpty(quotedBody))
        {
            fullBody += "\n\n-----Original Message-----\n" + quotedBody;
        }

        if (isHtml)
        {
            var htmlQuoted = !string.IsNullOrEmpty(quotedBody)
                ? $"<br/><br/><blockquote style=\"border-left:2px solid #ccc;padding-left:10px;color:#666;\">{quotedBody}</blockquote>"
                : "";
            var builder = new BodyBuilder { HtmlBody = body + htmlQuoted };
            message.Body = builder.ToMessageBody();
        }
        else
        {
            message.Body = new TextPart("plain") { Text = fullBody };
        }

        return message;
    }

    public static MimeMessage CreateForwardMessage(
        string fromEmail, string fromName,
        string to, string? cc, string subject, string body, bool isHtml,
        string originalFrom, string originalTo, string originalDate,
        string originalSubject, string? originalBody)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(fromName, fromEmail));

        foreach (var addr in ParseAddresses(to))
            message.To.Add(addr);

        if (!string.IsNullOrWhiteSpace(cc))
        {
            foreach (var addr in ParseAddresses(cc))
                message.Cc.Add(addr);
        }

        message.Subject = subject.StartsWith("Fwd:", StringComparison.OrdinalIgnoreCase)
            ? subject
            : $"Fwd: {subject}";

        // Build forwarded header block
        var fwdHeader = $"-----Forwarded Message-----\n" +
                        $"From: {originalFrom}\n" +
                        $"Date: {originalDate}\n" +
                        $"Subject: {originalSubject}\n" +
                        $"To: {originalTo}\n\n";

        var fullBody = body;
        if (!string.IsNullOrEmpty(originalBody))
            fullBody += "\n\n" + fwdHeader + originalBody;

        if (isHtml)
        {
            var htmlFwd = !string.IsNullOrEmpty(originalBody)
                ? $"<br/><br/><div style=\"border-left:2px solid #ccc;padding-left:10px;color:#666;\">" +
                  $"<p><b>-----Forwarded Message-----</b></p>" +
                  $"<p>From: {System.Net.WebUtility.HtmlEncode(originalFrom)}<br/>" +
                  $"Date: {System.Net.WebUtility.HtmlEncode(originalDate)}<br/>" +
                  $"Subject: {System.Net.WebUtility.HtmlEncode(originalSubject)}<br/>" +
                  $"To: {System.Net.WebUtility.HtmlEncode(originalTo)}</p>" +
                  $"<hr/>{originalBody}</div>"
                : "";
            var builder = new BodyBuilder { HtmlBody = body + htmlFwd };
            message.Body = builder.ToMessageBody();
        }
        else
        {
            message.Body = new TextPart("plain") { Text = fullBody };
        }

        return message;
    }

    private static List<MailboxAddress> ParseAddresses(string addresses)
    {
        var result = new List<MailboxAddress>();
        if (string.IsNullOrWhiteSpace(addresses)) return result;

        foreach (var addr in addresses.Split(';', ','))
        {
            var trimmed = addr.Trim();
            if (!string.IsNullOrEmpty(trimmed))
            {
                try
                {
                    result.Add(MailboxAddress.Parse(trimmed));
                }
                catch
                {
                    // If parsing fails, treat as plain email address
                    if (trimmed.Contains('@'))
                        result.Add(new MailboxAddress(trimmed, trimmed));
                }
            }
        }
        return result;
    }
}
