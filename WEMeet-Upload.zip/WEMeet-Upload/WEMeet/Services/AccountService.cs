using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using WEMeet.Models;

namespace WEMeet.Services;

public class AccountService
{
    private static readonly byte[] EntropyBytes = Encoding.UTF8.GetBytes("WEMeet_2024_AppData");

    public static string EncryptPassword(string password)
    {
        var plainBytes = Encoding.UTF8.GetBytes(password);
        var encryptedBytes = ProtectedData.Protect(plainBytes, EntropyBytes, DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string DecryptPassword(string encryptedPassword)
    {
        try
        {
            var encryptedBytes = Convert.FromBase64String(encryptedPassword);
            var plainBytes = ProtectedData.Unprotect(encryptedBytes, EntropyBytes, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plainBytes);
        }
        catch
        {
            return string.Empty;
        }
    }

    public async Task<List<MailAccount>> GetAllAccountsAsync()
    {
        using var db = new WeMeetDbContext();
        return await db.Accounts.ToListAsync();
    }

    public async Task<MailAccount?> GetAccountAsync(int id)
    {
        using var db = new WeMeetDbContext();
        return await db.Accounts.FindAsync(id);
    }

    public async Task<MailAccount> AddAccountAsync(MailAccount account, string password)
    {
        using var db = new WeMeetDbContext();
        account.EncryptedPassword = EncryptPassword(password);
        account.CreatedAt = DateTime.Now;
        db.Accounts.Add(account);
        await db.SaveChangesAsync();
        return account;
    }

    public async Task UpdateAccountAsync(MailAccount account, string? newPassword = null)
    {
        using var db = new WeMeetDbContext();
        if (!string.IsNullOrEmpty(newPassword))
            account.EncryptedPassword = EncryptPassword(newPassword);
        db.Accounts.Update(account);
        await db.SaveChangesAsync();
    }

    public async Task DeleteAccountAsync(int id)
    {
        using var db = new WeMeetDbContext();
        var account = await db.Accounts.FindAsync(id);
        if (account != null)
        {
            db.Accounts.Remove(account);
            await db.SaveChangesAsync();
        }
    }

    public async Task<List<MailFolder>> GetFoldersAsync(int accountId)
    {
        using var db = new WeMeetDbContext();
        return await db.Folders
            .Where(f => f.AccountId == accountId)
            .OrderBy(f => f.Name)
            .ToListAsync();
    }

    public async Task SaveFoldersAsync(int accountId, List<MailFolderInfo> folderInfos)
    {
        using var db = new WeMeetDbContext();
        // Remove existing
        var existing = await db.Folders.Where(f => f.AccountId == accountId).ToListAsync();
        db.Folders.RemoveRange(existing);

        // Add new
        foreach (var info in folderInfos)
        {
            db.Folders.Add(new MailFolder
            {
                AccountId = accountId,
                Name = info.Name,
                FullName = info.FullName,
                TotalCount = info.TotalCount,
                UnreadCount = info.UnreadCount
            });
        }
        await db.SaveChangesAsync();
    }

    public async Task SaveMessagesAsync(int accountId, List<MailMessage> messages)
    {
        using var db = new WeMeetDbContext();
        foreach (var msg in messages)
        {
            msg.AccountId = accountId;
            var exists = await db.Messages
                .AnyAsync(m => m.AccountId == accountId && m.Uid == msg.Uid && m.FolderName == msg.FolderName);
            if (!exists)
            {
                db.Messages.Add(msg);
            }
        }
        await db.SaveChangesAsync();
    }

    public async Task<List<MailMessage>> GetMessagesAsync(int accountId, string folderName, int skip = 0, int take = 50)
    {
        using var db = new WeMeetDbContext();
        return await db.Messages
            .Where(m => m.AccountId == accountId && m.FolderName == folderName && !m.IsDeleted)
            .OrderByDescending(m => m.Date)
            .Skip(skip)
            .Take(take)
            .ToListAsync();
    }

    public async Task MarkMessageAsReadAsync(int messageId)
    {
        using var db = new WeMeetDbContext();
        var msg = await db.Messages.FindAsync(messageId);
        if (msg != null)
        {
            msg.IsRead = true;
            await db.SaveChangesAsync();
        }
    }

    public async Task DeleteMessageAsync(int messageId)
    {
        using var db = new WeMeetDbContext();
        var msg = await db.Messages.FindAsync(messageId);
        if (msg != null)
        {
            msg.IsDeleted = true;
            await db.SaveChangesAsync();
        }
    }

    public async Task UpdateLastSyncAsync(int accountId)
    {
        using var db = new WeMeetDbContext();
        var account = await db.Accounts.FindAsync(accountId);
        if (account != null)
        {
            account.LastSyncDate = DateTime.Now;
            await db.SaveChangesAsync();
        }
    }
}
