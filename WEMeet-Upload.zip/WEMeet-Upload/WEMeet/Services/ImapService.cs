using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;
using MimeKit;
using WEMeet.Models;

namespace WEMeet.Services;

public class ImapService
{
    private static SecureSocketOptions GetSslOptions(int port, bool useSsl)
    {
        if (!useSsl) return SecureSocketOptions.None;
        return port switch
        {
            993 => SecureSocketOptions.SslOnConnect,
            143 => SecureSocketOptions.StartTlsWhenAvailable,
            _ => SecureSocketOptions.StartTlsWhenAvailable
        };
    }

    private static string FormatAuthError(Exception ex, string host)
    {
        var msg = ex.Message;
        if (msg.Contains("Authentication failed", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("Invalid credentials", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("Login failed", StringComparison.OrdinalIgnoreCase))
        {
            return $"Authentication failed. For Gmail/Outlook/Yahoo: use an App Password. " +
                   $"For QQ/163/126: use an Authorization Code (not your login password). " +
                   $"Detail: {msg}";
        }
        if (msg.Contains("connect", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("timeout", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("refused", StringComparison.OrdinalIgnoreCase))
        {
            return $"Cannot connect to {host}. Check server address and port. Detail: {msg}";
        }
        return msg;
    }

    public async Task<(bool Success, string Error)> TestConnectionAsync(
        string host, int port, bool ssl, string email, string password)
    {
        try
        {
            using var client = new ImapClient();
            await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
            await client.AuthenticateAsync(email, password);
            await client.DisconnectAsync(true);
            return (true, string.Empty);
        }
        catch (Exception ex)
        {
            return (false, FormatAuthError(ex, host));
        }
    }

    public async Task<List<MailFolderInfo>> GetFoldersAsync(
        string host, int port, bool ssl, string email, string password)
    {
        var folders = new List<MailFolderInfo>();
        using var client = new ImapClient();
        await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
        await client.AuthenticateAsync(email, password);

        // Try personal namespaces first
        try
        {
            var personalNamespaces = client.PersonalNamespaces;
            foreach (var ns in personalNamespaces)
            {
                try
                {
                    var root = client.GetFolder(ns);
                    await EnumerateFoldersAsync(root, folders);
                }
                catch { }
            }
        }
        catch { }

        // Fallback: try root folder
        if (folders.Count == 0)
        {
            try
            {
                var root = client.GetFolder(new FolderNamespace('/', string.Empty));
                await EnumerateFoldersAsync(root, folders);
            }
            catch { }
        }

        // Ensure INBOX is included
        if (!folders.Any(f => f.FullName.Equals("INBOX", StringComparison.OrdinalIgnoreCase)))
        {
            try
            {
                var inbox = client.Inbox;
                await inbox.OpenAsync(FolderAccess.ReadOnly);
                folders.Insert(0, new MailFolderInfo
                {
                    Name = "INBOX",
                    FullName = "INBOX",
                    TotalCount = inbox.Count,
                    UnreadCount = inbox.Unread
                });
                await inbox.CloseAsync();
            }
            catch { }
        }

        await client.DisconnectAsync(true);
        return folders;
    }

    private async Task EnumerateFoldersAsync(IMailFolder parent, List<MailFolderInfo> result)
    {
        try
        {
            var subfolders = await parent.GetSubfoldersAsync();
            foreach (var folder in subfolders)
            {
                try
                {
                    await folder.OpenAsync(FolderAccess.ReadOnly);
                    var info = new MailFolderInfo
                    {
                        Name = folder.Name,
                        FullName = folder.FullName,
                        TotalCount = folder.Count,
                        UnreadCount = folder.Unread
                    };
                    result.Add(info);
                    await folder.CloseAsync();
                }
                catch { /* Skip folders that can't be opened */ }

                if (folder.Attributes.HasFlag(FolderAttributes.HasChildren))
                {
                    await EnumerateFoldersAsync(folder, result);
                }
            }
        }
        catch { /* Skip folders that can't be accessed */ }
    }

    public async Task<List<MailMessage>> FetchMessageHeadersAsync(
        string host, int port, bool ssl, string email, string password,
        string folderName, int count = 50, CancellationToken cancellationToken = default)
    {
        var messages = new List<MailMessage>();
        using var client = new ImapClient();
        await client.ConnectAsync(host, port, GetSslOptions(port, ssl), cancellationToken);
        await client.AuthenticateAsync(email, password, cancellationToken);

        var folder = await GetFolderByFullNameAsync(client, folderName);
        if (folder == null) return messages;

        await folder.OpenAsync(FolderAccess.ReadOnly, cancellationToken);

        if (folder.Count == 0)
        {
            await client.DisconnectAsync(true, cancellationToken);
            return messages;
        }

        // Search for all UIDs, then take the last N (most recent)
        IList<UniqueId> fetchUids;
        try
        {
            var allUids = await folder.SearchAsync(SearchQuery.All, cancellationToken);
            // UIDs are in ascending order from IMAP SEARCH; take the last N
            fetchUids = allUids.Count <= count
                ? allUids.ToList()
                : allUids.Skip(allUids.Count - count).ToList();
        }
        catch
        {
            // Fallback: try SORT extension (date descending)
            try
            {
                var sorted = await folder.SortAsync(SearchQuery.All, new[] { OrderBy.ReverseDate }, cancellationToken);
                fetchUids = sorted.Take(count).ToList();
            }
            catch
            {
                // No more fallbacks - return empty
                await client.DisconnectAsync(true, cancellationToken);
                return messages;
            }
        }

        if (fetchUids.Count == 0)
        {
            await client.DisconnectAsync(true, cancellationToken);
            return messages;
        }

        var headers = await folder.FetchAsync(fetchUids,
            MessageSummaryItems.UniqueId |
            MessageSummaryItems.Envelope |
            MessageSummaryItems.Flags |
            MessageSummaryItems.BodyStructure |
            MessageSummaryItems.InternalDate,
            cancellationToken);

        foreach (var msg in headers.OrderByDescending(m => m.InternalDate ?? DateTime.MinValue))
        {
            var mailMsg = new MailMessage
            {
                Uid = msg.UniqueId.Id,
                FolderName = folderName,
                Date = msg.InternalDate?.LocalDateTime ?? DateTime.Now,
                IsRead = (msg.Flags ?? MessageFlags.None).HasFlag(MessageFlags.Seen),
                HasAttachments = msg.Attachments.Any()
            };

            mailMsg.MessageId = msg.Envelope?.MessageId;
            mailMsg.InReplyTo = msg.Envelope?.InReplyTo;

            if (msg.Envelope != null)
            {
                mailMsg.Subject = msg.Envelope.Subject ?? "(No Subject)";

                var fromAddr = msg.Envelope.From?.Mailboxes.FirstOrDefault();
                if (fromAddr != null)
                {
                    mailMsg.From = string.IsNullOrEmpty(fromAddr.Name) ? fromAddr.Address : fromAddr.Name;
                    mailMsg.FromAddress = fromAddr.Address;
                }
                else
                {
                    mailMsg.From = "Unknown";
                    mailMsg.FromAddress = "";
                }

                mailMsg.To = string.Join("; ",
                    msg.Envelope.To?.Mailboxes.Select(t =>
                        string.IsNullOrEmpty(t.Name) ? t.Address : $"{t.Name} <{t.Address}>")
                    ?? Array.Empty<string>());

                mailMsg.Cc = string.Join("; ",
                    msg.Envelope.Cc?.Mailboxes.Select(c =>
                        string.IsNullOrEmpty(c.Name) ? c.Address : $"{c.Name} <{c.Address}>")
                    ?? Array.Empty<string>());
            }

            messages.Add(mailMsg);
        }

        await client.DisconnectAsync(true, cancellationToken);
        return messages;
    }

    public async Task<(string Body, string? HtmlBody)> FetchMessageBodyAsync(
        string host, int port, bool ssl, string email, string password,
        string folderName, uint uid, CancellationToken cancellationToken = default)
    {
        using var client = new ImapClient();
        await client.ConnectAsync(host, port, GetSslOptions(port, ssl), cancellationToken);
        await client.AuthenticateAsync(email, password, cancellationToken);

        var folder = await GetFolderByFullNameAsync(client, folderName);
        if (folder == null) return (string.Empty, null);

        await folder.OpenAsync(FolderAccess.ReadOnly, cancellationToken);

        var message = await folder.GetMessageAsync(new UniqueId(uid), cancellationToken);

        string body = message.TextBody ?? string.Empty;
        string? htmlBody = message.HtmlBody;

        await client.DisconnectAsync(true, cancellationToken);
        return (body, htmlBody);
    }

    public async Task MarkAsReadAsync(
        string host, int port, bool ssl, string email, string password,
        string folderName, uint uid)
    {
        using var client = new ImapClient();
        await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
        await client.AuthenticateAsync(email, password);

        var folder = await GetFolderByFullNameAsync(client, folderName);
        if (folder == null) return;

        await folder.OpenAsync(FolderAccess.ReadWrite);
        await folder.AddFlagsAsync(new UniqueId(uid), MessageFlags.Seen, true);
        await client.DisconnectAsync(true);
    }

    public async Task DeleteMessageAsync(
        string host, int port, bool ssl, string email, string password,
        string folderName, uint uid)
    {
        using var client = new ImapClient();
        await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
        await client.AuthenticateAsync(email, password);

        var folder = await GetFolderByFullNameAsync(client, folderName);
        if (folder == null) return;

        await folder.OpenAsync(FolderAccess.ReadWrite);
        await folder.AddFlagsAsync(new UniqueId(uid), MessageFlags.Deleted, true);
        await folder.ExpungeAsync();
        await client.DisconnectAsync(true);
    }

    public async Task AppendToSentFolderAsync(
        string host, int port, bool ssl, string email, string password,
        MimeMessage message)
    {
        using var client = new ImapClient();
        await client.ConnectAsync(host, port, GetSslOptions(port, ssl));
        await client.AuthenticateAsync(email, password);

        IMailFolder? sentFolder = null;

        // Try SpecialFolder first (SPECIAL-USE extension)
        try { sentFolder = client.GetFolder(SpecialFolder.Sent); } catch { }

        // Try common Sent folder name patterns (including modified UTF-7 for Chinese)
        if (sentFolder == null)
        {
            string[] sentNames =
            {
                "Sent", "Sent Items", "Sent Messages",
                "INBOX.Sent", "INBOX/Sent",
                "[Gmail]/Sent Mail",
                "&XfJT0ZAB-",           // 已发送 (163/126)
                "&kAFP4W4IMH8-",        // 已发送邮件 (QQ)
                "&g0l6P3ux-",           // 已发送 (variant)
                "&XfJT0ZAB-",           // 已发送 (Sina)
                "已发送",                // Fallback Unicode
                "已发送邮件"
            };

            foreach (var name in sentNames)
            {
                try
                {
                    sentFolder = await client.GetFolderAsync(name);
                    if (sentFolder != null) break;
                }
                catch { }
            }
        }

        if (sentFolder != null)
        {
            try
            {
                await sentFolder.OpenAsync(FolderAccess.ReadWrite);
                await sentFolder.AppendAsync(message, MessageFlags.Seen);
                await sentFolder.CloseAsync();
            }
            catch { /* Non-critical if append to sent fails */ }
        }

        await client.DisconnectAsync(true);
    }

    private async Task<IMailFolder?> GetFolderByFullNameAsync(ImapClient client, string folderName)
    {
        try
        {
            return await client.GetFolderAsync(folderName);
        }
        catch
        {
            if (folderName.Equals("INBOX", StringComparison.OrdinalIgnoreCase))
            {
                return client.Inbox;
            }
            return null;
        }
    }
}

public class MailFolderInfo
{
    public string Name { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public int TotalCount { get; set; }
    public int UnreadCount { get; set; }
}
