namespace WEMeet.Services;

public class MailServerSettings
{
    public string ImapHost { get; set; } = string.Empty;
    public int ImapPort { get; set; } = 993;
    public bool ImapSsl { get; set; } = true;
    public string SmtpHost { get; set; } = string.Empty;
    public int SmtpPort { get; set; } = 587;
    public bool SmtpSsl { get; set; } = true;
    public string? ProviderHint { get; set; }
}

public static class AutoDiscoveryService
{
    private static readonly Dictionary<string, MailServerSettings> KnownProviders = new(StringComparer.OrdinalIgnoreCase)
    {
        ["gmail.com"] = new()
        {
            ImapHost = "imap.gmail.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.gmail.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Gmail requires an App Password. Go to: Google Account → Security → 2-Step Verification → App passwords."
        },
        ["googlemail.com"] = new()
        {
            ImapHost = "imap.gmail.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.gmail.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Gmail requires an App Password. Go to: Google Account → Security → 2-Step Verification → App passwords."
        },
        ["outlook.com"] = new()
        {
            ImapHost = "outlook.office365.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.office365.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Outlook may need an App Password if 2FA is on. Go to: Microsoft Account → Security → Advanced security options → App passwords."
        },
        ["hotmail.com"] = new()
        {
            ImapHost = "outlook.office365.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.office365.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Hotmail/Outlook may need an App Password if 2FA is on."
        },
        ["live.com"] = new()
        {
            ImapHost = "outlook.office365.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.office365.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Live/Outlook may need an App Password if 2FA is on."
        },
        ["yahoo.com"] = new()
        {
            ImapHost = "imap.mail.yahoo.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.mail.yahoo.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Yahoo requires an App Password. Go to: Yahoo Account Security → Generate app passwords."
        },
        ["yahoo.com.cn"] = new()
        {
            ImapHost = "imap.mail.yahoo.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.mail.yahoo.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Yahoo requires an App Password. Go to: Yahoo Account Security → Generate app passwords."
        },
        ["qq.com"] = new()
        {
            ImapHost = "imap.qq.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.qq.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "QQ Mail requires an Authorization Code (授权码), NOT your login password. Go to: QQ Mail Settings → Account → POP3/IMAP/SMTP → Generate authorization code."
        },
        ["foxmail.com"] = new()
        {
            ImapHost = "imap.qq.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.qq.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Foxmail uses QQ Mail servers. You need a QQ Mail Authorization Code (授权码)."
        },
        ["163.com"] = new()
        {
            ImapHost = "imap.163.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.163.com", SmtpPort = 465, SmtpSsl = true,
            ProviderHint = "163 Mail requires an Authorization Code (授权码), NOT your login password. Go to: 163 Mail Settings → POP3/IMAP/SMTP → Set client authorization code."
        },
        ["126.com"] = new()
        {
            ImapHost = "imap.126.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.126.com", SmtpPort = 465, SmtpSsl = true,
            ProviderHint = "126 Mail requires an Authorization Code (授权码), NOT your login password. Go to: 126 Mail Settings → POP3/IMAP/SMTP → Set client authorization code."
        },
        ["yeah.net"] = new()
        {
            ImapHost = "imap.yeah.net", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.yeah.net", SmtpPort = 465, SmtpSsl = true,
            ProviderHint = "Yeah Mail requires an Authorization Code (授权码). Go to: Settings → POP3/IMAP/SMTP → Set client authorization code."
        },
        ["sina.com"] = new()
        {
            ImapHost = "imap.sina.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.sina.com", SmtpPort = 465, SmtpSsl = true,
            ProviderHint = "Sina Mail may require enabling IMAP/SMTP in settings first."
        },
        ["aliyun.com"] = new()
        {
            ImapHost = "imap.aliyun.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.aliyun.com", SmtpPort = 465, SmtpSsl = true,
            ProviderHint = "Aliyun Mail may require enabling IMAP/SMTP in settings first."
        },
        ["icloud.com"] = new()
        {
            ImapHost = "imap.mail.me.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.mail.me.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "iCloud requires an App-Specific Password. Go to: appleid.apple.com → Sign-In and Security → App-Specific Passwords."
        },
        ["me.com"] = new()
        {
            ImapHost = "imap.mail.me.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.mail.me.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "iCloud requires an App-Specific Password. Go to: appleid.apple.com → Sign-In and Security → App-Specific Passwords."
        },
        ["zoho.com"] = new()
        {
            ImapHost = "imap.zoho.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.zoho.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Zoho Mail requires enabling IMAP access in settings for free accounts."
        },
        ["protonmail.com"] = new()
        {
            ImapHost = "127.0.0.1", ImapPort = 1143, ImapSsl = false,
            SmtpHost = "127.0.0.1", SmtpPort = 1025, SmtpSsl = false,
            ProviderHint = "ProtonMail requires Proton Mail Bridge app running locally. Download from: proton.me/mail/bridge"
        },
        ["proton.me"] = new()
        {
            ImapHost = "127.0.0.1", ImapPort = 1143, ImapSsl = false,
            SmtpHost = "127.0.0.1", SmtpPort = 1025, SmtpSsl = false,
            ProviderHint = "ProtonMail requires Proton Mail Bridge app running locally. Download from: proton.me/mail/bridge"
        },
        ["yandex.com"] = new()
        {
            ImapHost = "imap.yandex.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.yandex.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Yandex requires enabling IMAP access in Mail settings, and may need an App Password."
        },
        ["yandex.ru"] = new()
        {
            ImapHost = "imap.yandex.ru", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.yandex.ru", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Yandex requires enabling IMAP access in Mail settings, and may need an App Password."
        },
        ["mail.ru"] = new()
        {
            ImapHost = "imap.mail.ru", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.mail.ru", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "Mail.ru requires enabling IMAP in settings and may need an App Password for external clients."
        },
        ["gmx.com"] = new()
        {
            ImapHost = "imap.gmx.com", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.gmx.com", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "GMX requires enabling IMAP access in settings."
        },
        ["gmx.net"] = new()
        {
            ImapHost = "imap.gmx.net", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.gmx.net", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "GMX requires enabling IMAP access in settings."
        },
        ["web.de"] = new()
        {
            ImapHost = "imap.web.de", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.web.de", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "WEB.DE requires enabling IMAP access in settings."
        },
        ["t-online.de"] = new()
        {
            ImapHost = "imap.t-online.de", ImapPort = 993, ImapSsl = true,
            SmtpHost = "smtp.t-online.de", SmtpPort = 587, SmtpSsl = true,
            ProviderHint = "T-Online requires enabling IMAP and may need an App Password."
        }
    };

    public static MailServerSettings? Discover(string email)
    {
        var domain = email.Split('@').LastOrDefault();
        if (string.IsNullOrEmpty(domain)) return null;

        if (KnownProviders.TryGetValue(domain, out var settings))
            return settings;

        // Fallback: guess based on domain pattern
        return new MailServerSettings
        {
            ImapHost = $"imap.{domain}",
            ImapPort = 993,
            ImapSsl = true,
            SmtpHost = $"smtp.{domain}",
            SmtpPort = 587,
            SmtpSsl = true,
            ProviderHint = "This provider is not in the known list. Please verify server settings manually."
        };
    }

    public static bool IsKnownProvider(string email)
    {
        var domain = email.Split('@').LastOrDefault();
        return !string.IsNullOrEmpty(domain) && KnownProviders.ContainsKey(domain);
    }

    public static string? GetProviderHint(string email)
    {
        var domain = email.Split('@').LastOrDefault();
        if (string.IsNullOrEmpty(domain)) return null;
        return KnownProviders.TryGetValue(domain, out var settings) ? settings.ProviderHint : null;
    }
}
