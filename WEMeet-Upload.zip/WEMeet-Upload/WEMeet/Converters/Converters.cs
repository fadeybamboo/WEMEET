using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace WEMeet.Converters;

public class DateConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is DateTime date)
        {
            var now = DateTime.Now;
            if (date.Date == now.Date)
                return date.ToString("HH:mm");
            if (date.Year == now.Year)
                return date.ToString("MMM dd");
            return date.ToString("yyyy/MM/dd");
        }
        return string.Empty;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}

public class InverseBoolConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        return value is bool b ? !b : value;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        return value is bool b ? !b : value;
    }
}

public class NullToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        bool isVisible = value switch
        {
            null => false,
            string s => !string.IsNullOrEmpty(s),
            int i => i > 0,
            bool b => b,
            _ => true
        };
        if (parameter is string p && p == "Inverse")
            isVisible = !isVisible;
        return isVisible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
