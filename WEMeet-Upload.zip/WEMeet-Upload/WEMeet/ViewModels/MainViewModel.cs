using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HtmlAgilityPack;
using WEMeet.Models;
using WEMeet.Services;
using WEMeet.Views;

namespace WEMeet.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly AccountService _accountService = new();
    private readonly ImapService _imapService = new();
    private readonly SmtpService _smtpService = new();
    private readonly DispatcherTimer _autoRefreshTimer;

    [ObservableProperty] private ObservableCollection<AccountNode> _accounts = new();
    [ObservableProperty] private ObservableCollection<MailMessage> _messages = new();
    [ObservableProperty] private MailMessage? _selectedMessage;
    [ObservableProperty] private AccountNode? _selectedAccount;
    [ObservableProperty] private FolderNode? _selectedFolder;
    [ObservableProperty] private string _statusText = "Ready";
    [ObservableProperty] private bool _isLoading;
    [ObservableProperty] private string _messageBody = string.Empty;
    [ObservableProperty] private string _messageHtmlBody = string.Empty;
    [ObservableProperty] private bool _hasHtmlBody;

    public MainViewModel()
    {
        _ = InitializeAsync();

        // Auto-refresh every 5 minutes
        _autoRefreshTimer = new DispatcherTimer(TimeSpan.FromMinutes(5),
            DispatcherPriority.Background,
            OnAutoRefreshTick,
            Dispatcher.CurrentDispatcher);
        _autoRefreshTimer.Start();
    }

    private async void OnAutoRefreshTick(object? sender, EventArgs e)
    {
        if (SelectedFolder != null && !IsLoading)
        {
            try { await LoadMessagesAsync(); } catch { }
        }
    }

    private async Task InitializeAsync()
    {
        try
        {
            using var db = new WeMeetDbContext();
            db.EnsureCreated();
            await LoadAccountsAsync();
        }
        catch (Exception ex)
        {
            StatusText = $"Error: {ex.Message}";
        }
    }

    public async Task LoadAccountsAsync()
    {
        var accountList = await _accountService.GetAllAccountsAsync();
        Accounts.Clear();
        foreach (var account in accountList)
        {
            var node = new AccountNode(account);
            var folders = await _accountService.GetFoldersAsync(account.Id);
            foreach (var folder in folders)
            {
                node.Folders.Add(new FolderNode(folder));
            }
            Accounts.Add(node);
        }

        // Auto-select first account's inbox if available
        if (Accounts.Count > 0)
        {
            SelectedAccount = Accounts[0];
            var inbox = SelectedAccount.Folders.FirstOrDefault(f =>
                f.Folder.FullName.Equals("INBOX", StringComparison.OrdinalIgnoreCase));
            if (inbox != null)
            {
                SelectedFolder = inbox;
                await LoadMessagesAsync();
            }
        }
    }

    partial void OnSelectedFolderChanged(FolderNode? value)
    {
        if (value != null)
        {
            // Find the parent account
            foreach (var acct in Accounts)
            {
                if (acct.Folders.Contains(value))
                {
                    SelectedAccount = acct;
                    break;
                }
            }
            _ = LoadMessagesAsync();
        }
    }

    partial void OnSelectedMessageChanged(MailMessage? value)
    {
        if (value != null)
        {
            _ = LoadMessageBodyAsync(value);
        }
        else
        {
            MessageBody = string.Empty;
            MessageHtmlBody = string.Empty;
            HasHtmlBody = false;
        }
    }

    private async Task LoadMessagesAsync()
    {
        if (SelectedAccount == null || SelectedFolder == null) return;

        IsLoading = true;
        StatusText = "Loading messages...";

        try
        {
            var account = SelectedAccount.Account;
            var password = AccountService.DecryptPassword(account.EncryptedPassword);

            // Fetch from server
            var serverMessages = await _imapService.FetchMessageHeadersAsync(
                account.ImapHost, account.ImapPort, account.ImapSsl,
                account.Email, password,
                SelectedFolder.Folder.FullName, 50);

            // Save to local DB
            await _accountService.SaveMessagesAsync(account.Id, serverMessages);

            // Load from local DB
            var localMessages = await _accountService.GetMessagesAsync(
                account.Id, SelectedFolder.Folder.FullName);

            Messages = new ObservableCollection<MailMessage>(localMessages);
            await _accountService.UpdateLastSyncAsync(account.Id);
            StatusText = $"Loaded {localMessages.Count} messages. Last sync: {DateTime.Now:HH:mm}";
        }
        catch (Exception ex)
        {
            // Fallback to local messages
            try
            {
                var localMessages = await _accountService.GetMessagesAsync(
                    SelectedAccount.Account.Id, SelectedFolder.Folder.FullName);
                Messages = new ObservableCollection<MailMessage>(localMessages);
                StatusText = $"Offline mode - {localMessages.Count} messages. Error: {ex.Message}";
            }
            catch
            {
                StatusText = $"Error: {ex.Message}";
            }
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task LoadMessageBodyAsync(MailMessage message)
    {
        try
        {
            if (SelectedAccount == null) return;

            var account = SelectedAccount.Account;
            var password = AccountService.DecryptPassword(account.EncryptedPassword);

            var (body, htmlBody) = await _imapService.FetchMessageBodyAsync(
                account.ImapHost, account.ImapPort, account.ImapSsl,
                account.Email, password,
                message.FolderName, message.Uid);

            message.Body = body;
            message.HtmlBody = htmlBody;

            MessageBody = body;
            MessageHtmlBody = SanitizeHtml(htmlBody ?? "");
            HasHtmlBody = !string.IsNullOrEmpty(htmlBody);

            // Mark as read
            if (!message.IsRead)
            {
                await _accountService.MarkMessageAsReadAsync(message.Id);
                try { await _imapService.MarkAsReadAsync(
                    account.ImapHost, account.ImapPort, account.ImapSsl,
                    account.Email, password, message.FolderName, message.Uid); } catch { }
                message.IsRead = true;
                OnPropertyChanged(nameof(SelectedMessage));
            }
        }
        catch
        {
            MessageBody = message.Body ?? "";
            MessageHtmlBody = SanitizeHtml(message.HtmlBody ?? "");
            HasHtmlBody = !string.IsNullOrEmpty(message.HtmlBody);
        }
    }

    private string SanitizeHtml(string html)
    {
        if (string.IsNullOrEmpty(html)) return "";
        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        // Remove script tags
        var scripts = doc.DocumentNode.SelectNodes("//script") ?? new HtmlNodeCollection(doc.DocumentNode);
        foreach (var script in scripts.ToList())
            script.Remove();

        // Remove event handlers
        foreach (var node in doc.DocumentNode.Descendants())
        {
            var attrs = node.Attributes.Where(a => a.Name.StartsWith("on", StringComparison.OrdinalIgnoreCase)).ToList();
            foreach (var attr in attrs)
                node.Attributes.Remove(attr);
        }

        return doc.DocumentNode.OuterHtml;
    }

    [RelayCommand]
    private async Task RefreshAsync()
    {
        if (SelectedAccount == null) return;

        IsLoading = true;
        StatusText = "Syncing folders and messages...";

        try
        {
            var account = SelectedAccount.Account;
            var password = AccountService.DecryptPassword(account.EncryptedPassword);

            // Refresh folders
            var folders = await _imapService.GetFoldersAsync(
                account.ImapHost, account.ImapPort, account.ImapSsl,
                account.Email, password);
            await _accountService.SaveFoldersAsync(account.Id, folders);

            await LoadAccountsAsync();

            if (SelectedFolder != null)
                await LoadMessagesAsync();
        }
        catch (Exception ex)
        {
            StatusText = $"Sync error: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    [RelayCommand]
    private void AddAccount()
    {
        var dialog = new AddAccountDialog();
        dialog.Owner = Application.Current.MainWindow;
        if (dialog.ShowDialog() == true)
        {
            _ = LoadAccountsAsync();
        }
    }

    [RelayCommand]
    private async Task DeleteAccountAsync()
    {
        if (SelectedAccount == null) return;

        var result = MessageBox.Show(
            $"Remove account {SelectedAccount.Account.Email}?",
            "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);

        if (result == MessageBoxResult.Yes)
        {
            await _accountService.DeleteAccountAsync(SelectedAccount.Account.Id);
            await LoadAccountsAsync();
        }
    }

    [RelayCommand]
    private async Task DeleteMessageAsync()
    {
        if (SelectedMessage == null || SelectedAccount == null) return;

        var account = SelectedAccount.Account;
        var password = AccountService.DecryptPassword(account.EncryptedPassword);

        try
        {
            await _imapService.DeleteMessageAsync(
                account.ImapHost, account.ImapPort, account.ImapSsl,
                account.Email, password,
                SelectedMessage.FolderName, SelectedMessage.Uid);
            await _accountService.DeleteMessageAsync(SelectedMessage.Id);
            Messages.Remove(SelectedMessage);
            StatusText = "Message deleted";
        }
        catch (Exception ex)
        {
            StatusText = $"Delete error: {ex.Message}";
        }
    }

    [RelayCommand]
    private void Compose()
    {
        if (SelectedAccount == null)
        {
            MessageBox.Show("Please select an account first.", "WeMeet",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var window = new ComposeWindow(SelectedAccount.Account);
        window.Owner = Application.Current.MainWindow;
        window.ShowDialog();
    }

    [RelayCommand]
    private void Reply()
    {
        if (SelectedMessage == null || SelectedAccount == null) return;
        var window = new ComposeWindow(SelectedAccount.Account, SelectedMessage, false);
        window.Owner = Application.Current.MainWindow;
        window.ShowDialog();
    }

    [RelayCommand]
    private void ReplyAll()
    {
        if (SelectedMessage == null || SelectedAccount == null) return;
        var window = new ComposeWindow(SelectedAccount.Account, SelectedMessage, true);
        window.Owner = Application.Current.MainWindow;
        window.ShowDialog();
    }

    [RelayCommand]
    private void Forward()
    {
        if (SelectedMessage == null || SelectedAccount == null) return;
        var window = new ComposeWindow(SelectedAccount.Account, SelectedMessage, false, true);
        window.Owner = Application.Current.MainWindow;
        window.ShowDialog();
    }
}

public class AccountNode
{
    public MailAccount Account { get; }
    public ObservableCollection<FolderNode> Folders { get; } = new();
    public string DisplayName => Account.Name;
    public string Email => Account.Email;

    public AccountNode(MailAccount account)
    {
        Account = account;
    }
}

public class FolderNode
{
    public MailFolder Folder { get; }
    public string Name => Folder.Name;
    public string FullName => Folder.FullName;
    public int UnreadCount => Folder.UnreadCount;
    public string Icon => GetFolderIcon();

    private string GetFolderIcon()
    {
        var name = Folder.FullName.ToUpperInvariant();
        if (name.Contains("INBOX")) return "\u2709";
        if (name.Contains("SENT")) return "\u2794";
        if (name.Contains("DRAFT")) return "\u270E";
        if (name.Contains("TRASH") || name.Contains("DELETED")) return "\u2716";
        if (name.Contains("JUNK") || name.Contains("SPAM")) return "\u26A0";
        if (name.Contains("ARCHIVE")) return "\u2B1B";
        return "\uD83D\uDCC1";
    }

    public FolderNode(MailFolder folder)
    {
        Folder = folder;
    }
}
