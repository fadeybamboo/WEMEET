using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using WEMeet.Models;
using WEMeet.Services;

namespace WEMeet.ViewModels;

public partial class ComposeViewModel : ObservableObject
{
    private readonly SmtpService _smtpService = new();
    private readonly ImapService _imapService = new();
    private readonly AccountService _accountService = new();

    public MailAccount Account { get; }
    public MailMessage? ReplyToMessage { get; }
    public bool IsReply { get; }
    public bool IsReplyAll { get; }
    public bool IsForward { get; }

    [ObservableProperty] private string _to = string.Empty;
    [ObservableProperty] private string _cc = string.Empty;
    [ObservableProperty] private string _subject = string.Empty;
    [ObservableProperty] private string _body = string.Empty;
    [ObservableProperty] private bool _isHtml;
    [ObservableProperty] private bool _isSending;
    [ObservableProperty] private string _statusMessage = string.Empty;
    [ObservableProperty] private string _windowTitle = "New Message";

    public bool SentSuccessfully { get; private set; }

    public ComposeViewModel(MailAccount account)
    {
        Account = account;
        IsReply = false;
        IsReplyAll = false;
        IsForward = false;
        WindowTitle = $"New Message - {account.Email}";
    }

    public ComposeViewModel(MailAccount account, MailMessage originalMessage, bool replyAll = false, bool forward = false)
    {
        Account = account;
        ReplyToMessage = originalMessage;
        IsReply = !forward;
        IsReplyAll = replyAll && !forward;
        IsForward = forward;

        if (forward)
        {
            // Forward: empty To, prefixed subject, forwarded body
            Subject = originalMessage.Subject.StartsWith("Fwd:", StringComparison.OrdinalIgnoreCase)
                ? originalMessage.Subject
                : $"Fwd: {originalMessage.Subject}";

            var fwdBody = $"\n\n-----Forwarded Message-----\n" +
                          $"From: {originalMessage.From}\n" +
                          $"Date: {originalMessage.Date:yyyy-MM-dd HH:mm}\n" +
                          $"Subject: {originalMessage.Subject}\n" +
                          $"To: {originalMessage.To}\n\n";
            if (!string.IsNullOrEmpty(originalMessage.Body))
                fwdBody += originalMessage.Body;

            Body = fwdBody;
            WindowTitle = "Forward";
        }
        else
        {
            // Reply
            To = originalMessage.FromAddress;
            Subject = originalMessage.Subject.StartsWith("Re:", StringComparison.OrdinalIgnoreCase)
                ? originalMessage.Subject
                : $"Re: {originalMessage.Subject}";

            if (replyAll && !string.IsNullOrEmpty(originalMessage.Cc))
            {
                var ccList = originalMessage.Cc.Split(';', ',')
                    .Select(c => c.Trim())
                    .Where(c => !string.IsNullOrEmpty(c) && !c.Equals(account.Email, StringComparison.OrdinalIgnoreCase));
                Cc = string.Join("; ", ccList);
            }

            var quotedBody = $"\n\nOn {originalMessage.Date:yyyy-MM-dd HH:mm}, {originalMessage.From} wrote:\n";
            if (!string.IsNullOrEmpty(originalMessage.Body))
            {
                quotedBody += string.Join("\n",
                    originalMessage.Body.Split('\n').Select(line => $"> {line}"));
            }
            Body = quotedBody;
            WindowTitle = replyAll ? "Reply All" : "Reply";
        }
    }

    [RelayCommand]
    private async Task SendAsync()
    {
        if (string.IsNullOrEmpty(To))
        {
            StatusMessage = "Please enter at least one recipient.";
            return;
        }

        IsSending = true;
        StatusMessage = "Sending...";

        try
        {
            var password = AccountService.DecryptPassword(Account.EncryptedPassword);

            MimeKit.MimeMessage message;
            if (IsForward && ReplyToMessage != null)
            {
                message = SmtpService.CreateForwardMessage(
                    Account.Email, Account.Name,
                    To, string.IsNullOrEmpty(Cc) ? null : Cc,
                    Subject, Body, IsHtml,
                    ReplyToMessage.From, ReplyToMessage.To,
                    ReplyToMessage.Date.ToString("yyyy-MM-dd HH:mm"),
                    ReplyToMessage.Subject,
                    ReplyToMessage.Body);
            }
            else if (IsReply && ReplyToMessage != null)
            {
                message = SmtpService.CreateReplyMessage(
                    Account.Email, Account.Name,
                    To, ReplyToMessage.From,
                    string.IsNullOrEmpty(Cc) ? null : Cc,
                    Subject, Body, IsHtml,
                    ReplyToMessage.MessageId,
                    ReplyToMessage.Body);
            }
            else
            {
                message = SmtpService.CreateNewMessage(
                    Account.Email, Account.Name,
                    To, string.IsNullOrEmpty(Cc) ? null : Cc,
                    Subject, Body, IsHtml);
            }

            var (success, error) = await _smtpService.SendEmailAsync(
                Account.SmtpHost, Account.SmtpPort, Account.SmtpSsl,
                Account.Email, password, message);

            if (success)
            {
                StatusMessage = "Sent successfully!";
                SentSuccessfully = true;

                // Save to Sent folder
                try
                {
                    await _imapService.AppendToSentFolderAsync(
                        Account.ImapHost, Account.ImapPort, Account.ImapSsl,
                        Account.Email, password, message);
                }
                catch { /* Non-critical if append fails */ }
            }
            else
            {
                StatusMessage = $"Send failed: {error}";
            }
        }
        catch (Exception ex)
        {
            StatusMessage = $"Error: {ex.Message}";
        }
        finally
        {
            IsSending = false;
        }
    }

    [RelayCommand]
    private void ToggleHtml()
    {
        IsHtml = !IsHtml;
    }
}
