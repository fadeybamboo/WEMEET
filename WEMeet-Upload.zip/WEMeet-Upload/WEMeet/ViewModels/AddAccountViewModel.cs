using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using WEMeet.Models;
using WEMeet.Services;

namespace WEMeet.ViewModels;

public partial class AddAccountViewModel : ObservableObject
{
    private readonly ImapService _imapService = new();
    private readonly SmtpService _smtpService = new();
    private readonly AccountService _accountService = new();

    [ObservableProperty] private string _email = string.Empty;
    [ObservableProperty] private string _password = string.Empty;
    [ObservableProperty] private string _displayName = string.Empty;
    [ObservableProperty] private string _imapHost = string.Empty;
    [ObservableProperty] private int _imapPort = 993;
    [ObservableProperty] private bool _imapSsl = true;
    [ObservableProperty] private string _smtpHost = string.Empty;
    [ObservableProperty] private int _smtpPort = 587;
    [ObservableProperty] private bool _smtpSsl = true;
    [ObservableProperty] private bool _showManualConfig;
    [ObservableProperty] private bool _isTesting;
    [ObservableProperty] private string _statusMessage = string.Empty;
    [ObservableProperty] private bool _isSuccess;
    [ObservableProperty] private string _providerTip = string.Empty;

    public bool AccountAdded { get; private set; }

    partial void OnEmailChanged(string value)
    {
        if (!string.IsNullOrEmpty(value) && value.Contains('@'))
        {
            var settings = AutoDiscoveryService.Discover(value);
            if (settings != null && !ShowManualConfig)
            {
                ImapHost = settings.ImapHost;
                ImapPort = settings.ImapPort;
                ImapSsl = settings.ImapSsl;
                SmtpHost = settings.SmtpHost;
                SmtpPort = settings.SmtpPort;
                SmtpSsl = settings.SmtpSsl;
            }

            if (string.IsNullOrEmpty(DisplayName))
            {
                DisplayName = value.Split('@')[0];
            }

            // Use the provider hint from AutoDiscoveryService
            ProviderTip = AutoDiscoveryService.GetProviderHint(value) ?? string.Empty;
        }
        else
        {
            ProviderTip = string.Empty;
        }
    }

    [RelayCommand]
    private void ToggleManualConfig()
    {
        ShowManualConfig = !ShowManualConfig;
        if (!ShowManualConfig && !string.IsNullOrEmpty(Email) && Email.Contains('@'))
        {
            OnEmailChanged(Email);
        }
    }

    [RelayCommand]
    private async Task TestConnectionAsync()
    {
        if (string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
        {
            StatusMessage = "Please enter email and password.";
            IsSuccess = false;
            return;
        }

        IsTesting = true;
        StatusMessage = "Testing IMAP connection...";

        try
        {
            var (imapOk, imapError) = await _imapService.TestConnectionAsync(
                ImapHost, ImapPort, ImapSsl, Email, Password);

            if (!imapOk)
            {
                StatusMessage = $"IMAP Error: {imapError}";
                IsSuccess = false;
                IsTesting = false;
                return;
            }

            StatusMessage = "Testing SMTP connection...";
            var (smtpOk, smtpError) = await _smtpService.TestConnectionAsync(
                SmtpHost, SmtpPort, SmtpSsl, Email, Password);

            if (!smtpOk)
            {
                StatusMessage = $"SMTP Error: {smtpError}";
                IsSuccess = false;
                IsTesting = false;
                return;
            }

            StatusMessage = "Connection successful!";
            IsSuccess = true;
        }
        catch (Exception ex)
        {
            StatusMessage = $"Error: {ex.Message}";
            IsSuccess = false;
        }
        finally
        {
            IsTesting = false;
        }
    }

    [RelayCommand]
    private async Task SaveAccountAsync()
    {
        if (string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
        {
            StatusMessage = "Please enter email and password.";
            return;
        }

        try
        {
            var account = new MailAccount
            {
                Name = string.IsNullOrEmpty(DisplayName) ? Email.Split('@')[0] : DisplayName,
                Email = Email,
                ImapHost = ImapHost,
                ImapPort = ImapPort,
                ImapSsl = ImapSsl,
                SmtpHost = SmtpHost,
                SmtpPort = SmtpPort,
                SmtpSsl = SmtpSsl
            };

            await _accountService.AddAccountAsync(account, Password);

            // Fetch folders
            StatusMessage = "Saving account and fetching folders...";
            try
            {
                var folders = await _imapService.GetFoldersAsync(
                    ImapHost, ImapPort, ImapSsl, Email, Password);
                await _accountService.SaveFoldersAsync(account.Id, folders);
            }
            catch { /* Folder fetch can fail, user can sync later */ }

            AccountAdded = true;
            StatusMessage = "Account added successfully!";
            IsSuccess = true;
        }
        catch (Exception ex)
        {
            StatusMessage = $"Error saving: {ex.Message}";
            IsSuccess = false;
        }
    }
}
